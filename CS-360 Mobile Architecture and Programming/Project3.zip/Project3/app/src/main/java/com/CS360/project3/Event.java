package com.CS360.project3;

public class Event {

    long e_id;
    long u_id;
    String event = null;
    String details = null;
    long date;
    int alarm = 0;

}