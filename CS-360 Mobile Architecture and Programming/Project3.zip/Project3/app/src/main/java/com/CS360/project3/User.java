package com.CS360.project3;

public class User {
    long id = -1;
    String username = null;
    String password = null;
}
